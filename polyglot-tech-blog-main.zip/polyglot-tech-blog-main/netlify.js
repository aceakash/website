module.exports = { 
    baseUrl: "https://polyglot-tech-blog.netlify.app", 
    pathPrefix: "" 
};
