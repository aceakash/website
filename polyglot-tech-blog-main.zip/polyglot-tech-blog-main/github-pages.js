module.exports = { 
    baseUrl: "https://ftassy.github.io/Polyglot-Tech-Blog", 
    pathPrefix: "Polyglot-Tech-Blog" 
};
