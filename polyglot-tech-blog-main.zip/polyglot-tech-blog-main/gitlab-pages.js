module.exports = { 
    baseUrl: "https://florent_tassy.gitlab.io/polyglot-tech-blog", 
    pathPrefix: "polyglot-tech-blog" 
};
